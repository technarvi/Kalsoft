package skct.com.navigation;

import android.support.v4.app.Fragment;

import android.app.assist.AssistStructure;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by user on 15-09-2017.
 */

public class Entry extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View myview=inflater.inflate(R.layout.entry,container,false);
        return myview;

    }
}
